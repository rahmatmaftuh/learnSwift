//: [Previous](@previous)

import Foundation

class calculations {
   let a: Int
   let b: Int
   let res: Int

   init(a: Int, b: Int) {
      self.a = a
      self.b = b
      res = a + b
   }
   
   func tot(c: Int) -> Int {
      return res - c
   }
   
   func result() {
      print("Result is: \(tot(c: 20))")
      print("Result is: \(tot(c: 50))")
   }
}
let pri = calculations(a: 600, b: 300)
pri.result()

//keterangan
//Class Calculations defines two instance methods −
//
//init() is defined to add two numbers a and b and store it in result 'res'
//tot() is used to subtract the 'res' from passing 'c' value
//Finally, to print the calculations methods with values for a and b is called. Instance methods are accessed with '.' dot syntax

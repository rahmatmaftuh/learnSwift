//: [Previous](@previous)

import Foundation

//Loop statement = allows us to execute a statement or group of statements multiple times. Following is the general from of a loop statement in most of the programming languages

//1. for-in = This loop performs a set of statements for each item in a range, sequence, collection, or progression.

var Integers:[Int] = [10,20,30]
for wiu in Integers{
    print("Value of index is \(wiu)")
}
for number in 1...5{
    print("Hitungan ke \(number)")
}


//2. while loop = Repeats a statement or group of statements while a given condition is true. It tests the condition before executing the loop body.

var angka = 10

while angka<20{
    angka = angka+1
    print(angka)
}

//3. repeat..while loop = Like a while statement, except that it tests the condition at the end of the loop body.

var index = 2

repeat {
   print( "Value of index is \(index)")
   index = index + 1
}
while index < 20


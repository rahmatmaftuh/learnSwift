// Basic Syntax

import SwiftUI
var x = "Main Bola"
print (x)


//1. Semicolon (;)
//Swift 4 does not require you to type a semicolon (;) after each statement in your code, though it’s optional; and if you use a semicolon, then the compiler does not complain about it.
//However, if you are using multiple statements in the same line, then it is required to use a semicolon as a delimiter, otherwise the compiler will raise a syntax error. You can write the above Hello, World! program as follows −

var kocak = "Main Sepeda"; print(kocak)

//2. Identifier (Identifikasi)
//is a name used to identify a variable, function, or any other userdefined item. An identifier starts with an alphabet A to Z or a to z or an underscore _ followed by zero or more letters, underscores, and digits (0 to 9).

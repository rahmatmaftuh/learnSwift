//Built-in data types
import SwiftUI

//1. Int or UInt − This is used for whole numbers. More specifically, you can use Int32, Int64 to define 32 or 64 bit signed integer, whereas UInt32 or UInt64 to define 32 or 64 bit unsigned integer variables. For example, 42 and -23.
//2. Float − This is used to represent a 32-bit floating-point number and numbers with smaller decimal points. For example, 3.14159, 0.1, and -273.158.
//3. Double − This is used to represent a 64-bit floating-point number and used when floating-point values must be very large. For example, 3.14159, 0.1, and -273.158.
//4. Bool − This represents a Boolean value which is either true or false.
//5. String − This is an ordered collection of characters. For example, "Hello, World!"
//6. Character − This is a single-character string literal. For example, "C"
//7. Optional − This represents a variable that can hold either a value or no value.
//8. Tuples − This is used to group multiple values in single Compound Value.
var tupleExample = (501, "MAKAN")
print(tupleExample)

//Typealias = dia bisa ngeganti sebutan tipe datanya. Contoh semisal yang harusnya Int, bisa kita rename jadi bilbul
typealias bilbul = Int
var angka:bilbul = 500
print(angka)

typealias Feet = Int
var distance: Feet = 100
print(distance)

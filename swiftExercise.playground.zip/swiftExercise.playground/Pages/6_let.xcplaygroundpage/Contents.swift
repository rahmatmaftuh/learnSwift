//: [Previous](@previous)

import Foundation

//let or constants = Constants refer to fixed values that a program may not alter during its execution.

//1. Constant Declaration
//syntax: let constantName = <initial values>

let Nama = 93
print(Nama)
print(Nama.customMirror.subjectType)

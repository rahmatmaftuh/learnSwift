//: [Previous](@previous)

import Foundation

//Sets
//syntax var someSet = Set<Character>()     //Character can be replaced by data type of set.

//How to accessing sets
//  someSet.count// print number of Elements
//  someSet.insert("c") //adds element to set
//  someSet.isEmpty       // returns true or false depending on the set Elements.
//  someSet.remove("c")     // removes a element , removeAll() can be used to remove all elements
//  someSet.contains("c")     // to check if set contains this value.

let evens: Set = [10,12,14,16,18]
let odds: Set = [5,7,9,11,13]
let primes = [2,3,5,7]
odds.union(evens).sorted()
// [5,7,9,10,11,12,13,14,16,18]
odds.intersection(evens).sorted()
//[]
odds.subtracting(primes).sorted()
//[9, 11, 13]



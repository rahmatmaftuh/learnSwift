//: [Previous](@previous)

import Foundation

//1. if condition
var nama = "Mathew"
if nama == "Rahmat"{
    print(nama)
}

//2. if else condition

var name = "Mathew"
if name == "Rahmat"{
    print(name)
}else{
    print("Dia bukan Rahmat")
}

//3. if...else if
var namu = "Mathew"
if namu == "Rahmat"{
    print(namu)
}else if namu == "Mathew"{
    print("Dia adalah mathew")
}

//4. Nested if (didalam if terdapat if)
//syntax:
//if boolean_expression_1 {
//   /* Executes when the boolean expression 1 is true */
//
//   if boolean_expression_2 {
//      /* Executes when the boolean expression 2 is true */
//   }
//}

//example
var hewan = "Hiu"
var age = 22

if hewan == "Macan"{
    print("Ini adalah Macan")
    
    if age == 20{
        print ("Umurnya \(age) tahun")
    }else
        {print ("Umurnya adalah \(age) tahun")}
}else{
    print("Hewan tersebut bukan macan")
}

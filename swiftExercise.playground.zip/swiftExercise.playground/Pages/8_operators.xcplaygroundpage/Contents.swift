//: [Previous](@previous)

import Foundation

//Arithmetic Operators
//  +  means Adds two operands
//  −  means Subtracts second operand from the first
//  *  means Multiplies both operands
//  %  means  Modulus Operator and remainder of after an integer/float division

//Comparison Operators
// ==  means  equal
// !=  means not equal (Tidak sama dengan
//  >  means lebih dari
//  <  means kurang dari
//  >= means lebih dari sama dengan
//  <= means kurang dari sama dengan

//Logical operator

//&& means AND
//|| means OR
//!  means NOT Operator

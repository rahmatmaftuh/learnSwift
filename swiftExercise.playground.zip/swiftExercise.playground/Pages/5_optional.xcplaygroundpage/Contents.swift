//: [Previous](@previous)

import Foundation

//Optional = mengatasi ketiadaan nilai. Optional is a type on its own, actually one of Swift 4’s new super-powered enums. It has two possible values, None and Some(T), where T is an associated value of the correct data type available in Swift 4.

var perhapsString:String?
var perhapsStrong:String? = nil
//print(pershapsString)
//print(pershapsStrong)

if perhapsString != nil {
    print("Ini tidak nil")
}else{
    print("Ini nilainya nil")
}

//Forced unwrapping = If you defined a variable as optional, then to get the value from this variable, you will have to unwrap it. This just means putting an exclamation mark at the end of the variable.
var myString:String?

myString = "Hello, Swift 4!"

if myString != nil {
   print(myString!) //ini kalau nilainya 0, dia dianggap aja kalau hasilnya tuh si hello swift 4
} else {
   print("myString has nil value")
}

//Automatic Unwrapping = You can declare optional variables using exclamation mark instead of a question mark.
var timBola:String!

timBola = "Manchester United"

if timBola != "Manchester United"{
    print(timBola)
}else{
    print("you're mancunian")
}

//: [Previous](@previous)

import Foundation

//literals = A literal is the source code representation of a value of an integer, floating-point number, or string type

42 //Integer Literal
3.14159 //Floating-point literal
"Hello, world" //String literal

//String literals
//  \0    Null Character
//  \\    \character
//  \b    Backspace
//  \f    Form feed
//  \n    Newline
//  \r    Carriage return
//  \t    Horizontal tab
//  \v    Vertical tab
//  \'    Single Quote
//  \"    Double Quote
//  \000    Octal number of one to three digits
//  \xhh...    Hexadecimal number of one or more digits

print("rahmat \n(ihsan)")

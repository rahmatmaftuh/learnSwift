//: [Previous](@previous)

import Foundation

//Closures
//Closures in Swift 4 are similar to that of self-contained functions organized as blocks and called anywhere like C and Objective C languages.

let studname = {print("Welcome to ILB Cohort 3")}
studname()

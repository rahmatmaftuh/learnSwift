//: [Previous](@previous)

import Foundation

//Function definition = Every function has a function name, which describes the task that the function performs. To use a function, you "call" that function with its name and pass input values (known as arguments) that match the types of the function's parameters. Function parameters are also called as 'tuples'.

//syntax example
//func funcname(Parameters) -> returntype {
//   Statement1
//   Statement2
//   ---
//   Statement N
//   return parameters
//}

//1. basic function
func basicFunction() {
    print("This is basic function")
}
basicFunction()

//2. function with parameter
funcWithParam(parameter:"love you")
func funcWithParam(parameter: String){
    print("This function's parameter is: \(parameter)")
}

//3. function with parameter > 1
funcWithParam(param1:"love you", param2:1000)
func funcWithParam(param1: String, param2: Int){
    print("I want to say \(param1) \(param2) times")
}

//4. func with return
//syntaxnya
//func (namafunction(parameter)) -> <typedata>{
//   return <nilai yg dimau>
//}

func funcThatReturns()-> Int{
    return 30
}
var anInt = funcThatReturns()
print(anInt)

//4. func with param that return
func luasPersegi(sisi:Int) -> Int{
    let luas = sisi * sisi
    return luas
}
print(luasPersegi(sisi:4))




func ls(array: [Int]) -> (large: Int, small: Int) {
   var lar = array[0]
   var sma = array[0]

   for i in array[1..<array.count] {
      if i < sma {
         sma = i
      } else if i > lar {
         lar = i
      }
   }
   return (lar, sma)
}

let num = ls(array: [40,12,-5,78,98])
print("Largest number is: \(num.large) and smallest number is: \(num.small)")


//: [Previous](@previous)

import Foundation

//1. Variable declaration = A variable declaration tells the compiler where and how much to create the storage for the variable. Before you use variables, you must declare them using var keyword as follows −
//syntax: var variableName = <initial values>

var Nama = "Rahmat"
var Umur = 21
print(Nama, Umur, "tahun")

//2. Type annotations = You can provide a type annotation when you declare a variable, to be clear about the kind of values the variable can store.
//syntax: var variableName:<data type> = <optional initial values>
var bilanganDesimal:Float = 39.881
print(bilanganDesimal)

//3. Naming variables = The name of a variable can be composed of letters, digits, and the underscore character. It must begin with either a letter or an underscore. Upper and lowercase letters are distinct because Swift 4 is a case-sensitive programming language. Also you can use simple or Unicode characters to name your variables. The following examples shows how you can name the variables −

var 你好 = "你好世界"
print(你好)

//4. Printing variables = You can print the current value of a constant or variable with the print function
var hewan:String = "Ikan duyung"
var habitat:String = "Laut"
print("Apakah \(hewan) hidup di \(habitat)?")


//: [Previous](@previous)

import Foundation

//enum = An enumeration is a user-defined data type which consists of set of related values. Keyword enum is used to defined enumerated data type.

enum names {
   case Swift
   case Closures
}

var lang = names.Swift
lang = .Swift

switch lang {
   case .Swift:
      print("Welcome to Swift")
   case .Closures:
      print("Welcome to Closures")
   default:
      print("Introduction")
}
